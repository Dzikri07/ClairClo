-- Database Backup
-- Generated: 2025-11-20 13:52:49

-- Table: users
DELETE FROM `users`;
INSERT INTO `users` VALUES ('1', 'admin', 'admin@clariocloud.local', '$2y$10$WvczDfoFTRxlvkqcOo.L2.cLRpg9CGWZ4GGE5qOK7QTBVqSGsFDR2', 'Administrator', '107374182400', '0', NULL, '1', '1', '2025-11-20 19:52:15', '2025-11-19 18:41:41', '2025-11-20 19:52:15');
INSERT INTO `users` VALUES ('3', 'user', 'user@clairocloud.local', '$2y$10$CBA0ZeR9xJVsS8EQ.8blKuLia/90ISYGua8SvMLaTJ44OVu1WKZUW', 'dzikri', '1073741824', '208700', NULL, '1', '0', '2025-11-20 17:02:15', '2025-11-19 18:43:04', '2025-11-20 17:16:54');
INSERT INTO `users` VALUES ('4', 'user12', 'dzikri.muhammad36@gmail.com', '$2y$10$tcGMfMighF0kkGdLSOheO.r7bIVL301YwjN0gjZmP4BqPdfHY6ho6', 'dzikri', '5368709120', '0', NULL, '1', '0', NULL, '2025-11-19 13:38:39', '2025-11-19 19:38:39');
INSERT INTO `users` VALUES ('5', 'user3', 'user3@gmail.com', '$2y$10$chkYfodCHIM7wek/dMh4y..ZXZy1rBYJJob8P/rDlwAnbWqiCW7iK', 'usup', '10737418240', '357522', NULL, '1', '0', '2025-11-20 19:44:31', '2025-11-19 13:41:59', '2025-11-20 19:44:31');

-- Table: files
DELETE FROM `files`;
INSERT INTO `files` VALUES ('1', '5', '5', 'activity_logs_2025-11-19_12-56-26_1763557042_691dbeb2d8a01.csv', 'user_5\\activity_logs_2025-11-19_12-56-26_1763557042_691dbeb2d8a01.csv', NULL, 'activity_logs_2025-11-19_12-56-26.csv', NULL, 'text/plain', 'csv', '127', '0', '2025-11-19 19:57:22', NULL, '0', '0', NULL);
INSERT INTO `files` VALUES ('2', '5', '1', '2025-2026_ganjil_tugas_activity_diagram_1763557053_691dbebd6a842.docx', 'user_5\\2025-2026_ganjil_tugas_activity_diagram_1763557053_691dbebd6a842.docx', NULL, '2025-2026 ganjil tugas activity diagram.docx', NULL, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', '274238', '1', '2025-11-19 19:57:33', '2025-11-19 20:18:01', '0', '0', NULL);
INSERT INTO `files` VALUES ('4', '5', '5', 'activity_logs_2025-11-19_12-56-26_1763557083_691dbedba9a68.csv', 'user_5\\activity_logs_2025-11-19_12-56-26_1763557083_691dbedba9a68.csv', NULL, 'activity_logs_2025-11-19_12-56-26.csv', NULL, 'text/plain', 'csv', '127', '0', '2025-11-19 19:58:03', NULL, '0', '0', NULL);
INSERT INTO `files` VALUES ('5', '5', '2', 'Bored_Valkyrie__1__1763560017_691dca51536f0.png', 'user_5\\Bored_Valkyrie__1__1763560017_691dca51536f0.png', NULL, 'Bored_Valkyrie (1).png', NULL, 'image/png', 'png', '25354', '0', '2025-11-19 20:46:57', NULL, '0', '1', '2025-11-20 12:07:19');
INSERT INTO `files` VALUES ('6', '3', '1', 'get_return_label_1763624799_691ec75f2d86a.pdf', 'user_3\\get_return_label_1763624799_691ec75f2d86a.pdf', NULL, 'get_return_label.pdf', NULL, 'application/pdf', 'pdf', '103766', '0', '2025-11-20 14:46:39', NULL, '0', '1', '2025-11-20 10:00:59');
INSERT INTO `files` VALUES ('7', '3', '5', 'users_export_2025-11-20_09-21-44_1763629309_691ed8fdc4bc7.csv', 'user_3\\users_export_2025-11-20_09-21-44_1763629309_691ed8fdc4bc7.csv', NULL, 'users_export_2025-11-20_09-21-44.csv', NULL, 'application/csv', 'csv', '292', '1', '2025-11-20 16:01:49', '2025-11-20 16:07:48', '0', '1', '2025-11-20 10:16:58');
INSERT INTO `files` VALUES ('8', '3', '5', 'users_export_2025-11-20_09-21-44__1__1763630739_691ede93eb036.csv', 'user_3\\users_export_2025-11-20_09-21-44__1__1763630739_691ede93eb036.csv', NULL, 'users_export_2025-11-20_09-21-44 (1).csv', NULL, 'application/csv', 'csv', '292', '0', '2025-11-20 16:25:39', NULL, '1', '1', '2025-11-20 11:09:56');
INSERT INTO `files` VALUES ('9', '3', '1', 'get_return_label_1763633096_691ee7c897739.pdf', 'user_3\\get_return_label_1763633096_691ee7c897739.pdf', NULL, 'get_return_label.pdf', NULL, 'application/pdf', 'pdf', '103766', '0', '2025-11-20 17:04:56', NULL, '1', '1', '2025-11-20 11:09:49');
INSERT INTO `files` VALUES ('10', '3', '5', 'users_export_2025-11-20_09-21-44__1__1763633494_691ee95676b5c.csv', 'user_3\\users_export_2025-11-20_09-21-44__1__1763633494_691ee95676b5c.csv', NULL, 'users_export_2025-11-20_09-21-44 (1).csv', NULL, 'application/csv', 'csv', '292', '0', '2025-11-20 17:11:34', NULL, '0', '1', '2025-11-20 11:11:52');
INSERT INTO `files` VALUES ('11', '3', '5', 'users_export_2025-11-20_09-21-44__1__1763633814_691eea969f371.csv', 'user_3\\users_export_2025-11-20_09-21-44__1__1763633814_691eea969f371.csv', NULL, 'users_export_2025-11-20_09-21-44 (1).csv', NULL, 'application/csv', 'csv', '292', '0', '2025-11-20 17:16:54', NULL, '0', '0', NULL);
INSERT INTO `files` VALUES ('12', '5', '8', 'index__2__1763640688_691f057039fe0.php', 'user_5\\index__2__1763640688_691f057039fe0.php', NULL, 'index (2).php', NULL, 'text/html', 'php', '28838', '0', '2025-11-20 19:11:28', NULL, '0', '0', NULL);
INSERT INTO `files` VALUES ('13', '5', '8', 'index__2__1763640734_691f059e6ae59.php', 'user_5\\index__2__1763640734_691f059e6ae59.php', NULL, 'index (2).php', NULL, 'text/html', 'php', '28838', '0', '2025-11-20 19:12:14', NULL, '1', '0', NULL);

-- Table: file_categories
DELETE FROM `file_categories`;
INSERT INTO `file_categories` VALUES ('1', 'Documents', 'documents', 'Document files including PDF, Word, Text files', 'pdf,doc,docx,txt,rtf,odt', '52428800', 'fa-file-text', '#3498db', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('2', 'Images', 'images', 'Image files including PNG, JPG, GIF, SVG', 'jpg,jpeg,png,gif,bmp,svg,webp,ico', '10485760', 'fa-image', '#e74c3c', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('3', 'Videos', 'videos', 'Video files including MP4, AVI, MOV, MKV', 'mp4,avi,mov,mkv,wmv,flv,webm,m4v', '524288000', 'fa-video', '#9b59b6', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('4', 'Audio', 'audio', 'Audio files including MP3, WAV, OGG', 'mp3,wav,ogg,m4a,flac,aac,wma', '52428800', 'fa-music', '#1abc9c', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('5', 'Spreadsheets', 'spreadsheets', 'Spreadsheet files including Excel, CSV', 'xlsx,xls,csv,ods', '20971520', 'fa-table', '#27ae60', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('6', 'Presentations', 'presentations', 'Presentation files including PowerPoint', 'ppt,pptx,odp,key', '52428800', 'fa-presentation', '#f39c12', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('7', 'Archives', 'archives', 'Compressed archive files', 'zip,rar,7z,tar,gz,bz2', '104857600', 'fa-archive', '#95a5a6', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('8', 'Code', 'code', 'Source code and programming files', 'php,js,html,css,json,xml,sql,py,java,cpp,c,h,sh', '5242880', 'fa-code', '#34495e', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('9', 'Others', 'others', 'Other file types not categorized', '*', '104857600', 'fa-file', '#7f8c8d', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');

-- Table: file_storage_paths
DELETE FROM `file_storage_paths`;
INSERT INTO `file_storage_paths` VALUES ('1', '1', '5', 'uploads\\user_5', 'user_5\\activity_logs_2025-11-19_12-56-26_1763557042_691dbeb2d8a01.csv', NULL, 'activity_logs_2025-11-19_12-56-26.csv', 'activity_logs_2025-11-19_12-56-26_1763557042_691dbeb2d8a01.csv', '127', 'text/plain', 'csv', '0', NULL, '0', NULL, '2025-11-19 19:57:22', '2025-11-19 19:57:22');
INSERT INTO `file_storage_paths` VALUES ('2', '2', '5', 'uploads\\user_5', 'user_5\\2025-2026_ganjil_tugas_activity_diagram_1763557053_691dbebd6a842.docx', NULL, '2025-2026 ganjil tugas activity diagram.docx', '2025-2026_ganjil_tugas_activity_diagram_1763557053_691dbebd6a842.docx', '274238', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', '1', '2025-11-19 20:18:01', '0', NULL, '2025-11-19 19:57:33', '2025-11-19 20:18:27');
INSERT INTO `file_storage_paths` VALUES ('4', '4', '5', 'uploads\\user_5', 'user_5\\activity_logs_2025-11-19_12-56-26_1763557083_691dbedba9a68.csv', NULL, 'activity_logs_2025-11-19_12-56-26.csv', 'activity_logs_2025-11-19_12-56-26_1763557083_691dbedba9a68.csv', '127', 'text/plain', 'csv', '0', NULL, '0', NULL, '2025-11-19 19:58:03', '2025-11-19 19:58:03');
INSERT INTO `file_storage_paths` VALUES ('5', '5', '5', 'uploads\\user_5', 'user_5\\Bored_Valkyrie__1__1763560017_691dca51536f0.png', NULL, 'Bored_Valkyrie (1).png', 'Bored_Valkyrie__1__1763560017_691dca51536f0.png', '25354', 'image/png', 'png', '0', NULL, '1', '2025-11-20 12:07:19', '2025-11-19 20:46:57', '2025-11-20 18:07:19');
INSERT INTO `file_storage_paths` VALUES ('6', '6', '3', 'uploads\\user_3', 'user_3\\get_return_label_1763624799_691ec75f2d86a.pdf', NULL, 'get_return_label.pdf', 'get_return_label_1763624799_691ec75f2d86a.pdf', '103766', 'application/pdf', 'pdf', '0', NULL, '1', '2025-11-20 10:00:59', '2025-11-20 14:46:39', '2025-11-20 16:00:59');
INSERT INTO `file_storage_paths` VALUES ('7', '7', '3', 'uploads\\user_3', 'user_3\\users_export_2025-11-20_09-21-44_1763629309_691ed8fdc4bc7.csv', NULL, 'users_export_2025-11-20_09-21-44.csv', 'users_export_2025-11-20_09-21-44_1763629309_691ed8fdc4bc7.csv', '292', 'application/csv', 'csv', '1', '2025-11-20 16:07:48', '1', '2025-11-20 10:16:58', '2025-11-20 16:01:49', '2025-11-20 16:16:58');
INSERT INTO `file_storage_paths` VALUES ('8', '8', '3', 'uploads\\user_3', 'user_3\\users_export_2025-11-20_09-21-44__1__1763630739_691ede93eb036.csv', NULL, 'users_export_2025-11-20_09-21-44 (1).csv', 'users_export_2025-11-20_09-21-44__1__1763630739_691ede93eb036.csv', '292', 'application/csv', 'csv', '0', NULL, '1', '2025-11-20 11:09:56', '2025-11-20 16:25:39', '2025-11-20 17:09:56');
INSERT INTO `file_storage_paths` VALUES ('9', '9', '3', 'uploads\\user_3', 'user_3\\get_return_label_1763633096_691ee7c897739.pdf', NULL, 'get_return_label.pdf', 'get_return_label_1763633096_691ee7c897739.pdf', '103766', 'application/pdf', 'pdf', '0', NULL, '1', '2025-11-20 11:09:49', '2025-11-20 17:04:56', '2025-11-20 17:09:49');
INSERT INTO `file_storage_paths` VALUES ('10', '10', '3', 'uploads\\user_3', 'user_3\\users_export_2025-11-20_09-21-44__1__1763633494_691ee95676b5c.csv', NULL, 'users_export_2025-11-20_09-21-44 (1).csv', 'users_export_2025-11-20_09-21-44__1__1763633494_691ee95676b5c.csv', '292', 'application/csv', 'csv', '0', NULL, '1', '2025-11-20 11:11:52', '2025-11-20 17:11:34', '2025-11-20 17:11:52');
INSERT INTO `file_storage_paths` VALUES ('11', '11', '3', 'uploads\\user_3', 'user_3\\users_export_2025-11-20_09-21-44__1__1763633814_691eea969f371.csv', NULL, 'users_export_2025-11-20_09-21-44 (1).csv', 'users_export_2025-11-20_09-21-44__1__1763633814_691eea969f371.csv', '292', 'application/csv', 'csv', '0', NULL, '0', NULL, '2025-11-20 17:16:54', '2025-11-20 17:16:54');
INSERT INTO `file_storage_paths` VALUES ('12', '12', '5', 'uploads\\user_5', 'user_5\\index__2__1763640688_691f057039fe0.php', NULL, 'index (2).php', 'index__2__1763640688_691f057039fe0.php', '28838', 'text/html', 'php', '0', NULL, '0', NULL, '2025-11-20 19:11:28', '2025-11-20 19:11:28');
INSERT INTO `file_storage_paths` VALUES ('13', '13', '5', 'uploads\\user_5', 'user_5\\index__2__1763640734_691f059e6ae59.php', NULL, 'index (2).php', 'index__2__1763640734_691f059e6ae59.php', '28838', 'text/html', 'php', '0', NULL, '0', NULL, '2025-11-20 19:12:14', '2025-11-20 19:12:14');

-- Table: storage_requests
DELETE FROM `storage_requests`;
INSERT INTO `storage_requests` VALUES ('1', '3', '12884901888', '1073741824', '12', 'pending', NULL, NULL, '2025-11-20 14:44:47', NULL);

-- Table: activity_logs
DELETE FROM `activity_logs`;
INSERT INTO `activity_logs` VALUES ('1', NULL, 'EXPORT_USERS', 'Exported 2 user records to CSV', '2025-11-19 18:56:26', '::1');
INSERT INTO `activity_logs` VALUES ('2', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-19 18:56:26', '::1');
INSERT INTO `activity_logs` VALUES ('3', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-19_13-26-09.zip ( bytes, 0 files included)', '2025-11-19 19:26:09', '::1');
INSERT INTO `activity_logs` VALUES ('4', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-19_13-28-35.zip (0 bytes, 0 files included)', '2025-11-19 19:28:35', '::1');
INSERT INTO `activity_logs` VALUES ('5', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-19_13-28-39.zip (0 bytes, 0 files included)', '2025-11-19 19:28:39', '::1');
INSERT INTO `activity_logs` VALUES ('6', NULL, 'MANUAL_ENTRY', '2233', '2025-11-20 15:18:31', '::1');
INSERT INTO `activity_logs` VALUES ('7', NULL, 'MANUAL_ENTRY', '323232333', '2025-11-20 15:18:34', '::1');
INSERT INTO `activity_logs` VALUES ('8', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-20 15:20:39', '::1');
INSERT INTO `activity_logs` VALUES ('9', NULL, 'EXPORT_USERS', 'Exported 3 user records to CSV', '2025-11-20 15:21:04', '::1');
INSERT INTO `activity_logs` VALUES ('10', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-20 15:21:42', '::1');
INSERT INTO `activity_logs` VALUES ('11', NULL, 'EXPORT_USERS', 'Exported 3 user records to CSV', '2025-11-20 15:21:44', '::1');
INSERT INTO `activity_logs` VALUES ('12', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-20_09-28-30.zip (0 bytes, 0 files included)', '2025-11-20 15:28:31', '::1');
INSERT INTO `activity_logs` VALUES ('13', NULL, 'DELETE_INTERNAL_FILE', 'Deleted file: 1763627564_users_export_2025-11-20_09-21-44.csv', '2025-11-20 15:32:47', '::1');

