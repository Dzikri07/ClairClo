-- Database Backup
-- Generated: 2025-11-21 02:35:13

-- Table: users
DELETE FROM `users`;
INSERT INTO `users` VALUES ('1', 'admin', 'admin@clariocloud.local', '$2y$10$WvczDfoFTRxlvkqcOo.L2.cLRpg9CGWZ4GGE5qOK7QTBVqSGsFDR2', 'Administrator', '107374182400', '0', NULL, '1', '1', '2025-11-21 07:43:51', '2025-11-19 18:41:41', '2025-11-21 07:43:51');
INSERT INTO `users` VALUES ('3', 'user', 'user@clairocloud.local', '$2y$10$CBA0ZeR9xJVsS8EQ.8blKuLia/90ISYGua8SvMLaTJ44OVu1WKZUW', 'dzikri', '12884901888', '1991706', NULL, '1', '0', '2025-11-21 06:06:58', '2025-11-19 18:43:04', '2025-11-21 06:52:36');
INSERT INTO `users` VALUES ('4', 'user12', 'dzikri.muhammad36@gmail.com', '$2y$10$tcGMfMighF0kkGdLSOheO.r7bIVL301YwjN0gjZmP4BqPdfHY6ho6', 'dzikri', '5368709120', '0', NULL, '1', '0', NULL, '2025-11-19 13:38:39', '2025-11-19 19:38:39');
INSERT INTO `users` VALUES ('5', 'user3', 'user3@gmail.com', '$2y$10$chkYfodCHIM7wek/dMh4y..ZXZy1rBYJJob8P/rDlwAnbWqiCW7iK', 'usup', '42949672960', '357522', NULL, '1', '0', '2025-11-20 23:18:06', '2025-11-19 13:41:59', '2025-11-20 23:18:06');

-- Table: files
DELETE FROM `files`;
INSERT INTO `files` VALUES ('1', '5', '5', 'activity_logs_2025-11-19_12-56-26_1763557042_691dbeb2d8a01.csv', 'user_5\\activity_logs_2025-11-19_12-56-26_1763557042_691dbeb2d8a01.csv', NULL, 'activity_logs_2025-11-19_12-56-26.csv', NULL, 'text/plain', 'csv', '127', '0', '2025-11-19 19:57:22', NULL, '0', '0', NULL);
INSERT INTO `files` VALUES ('2', '5', '1', '2025-2026_ganjil_tugas_activity_diagram_1763557053_691dbebd6a842.docx', 'user_5\\2025-2026_ganjil_tugas_activity_diagram_1763557053_691dbebd6a842.docx', NULL, '2025-2026 ganjil tugas activity diagram.docx', NULL, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', '274238', '1', '2025-11-19 19:57:33', '2025-11-19 20:18:01', '0', '0', NULL);
INSERT INTO `files` VALUES ('4', '5', '5', 'activity_logs_2025-11-19_12-56-26_1763557083_691dbedba9a68.csv', 'user_5\\activity_logs_2025-11-19_12-56-26_1763557083_691dbedba9a68.csv', NULL, 'activity_logs_2025-11-19_12-56-26.csv', NULL, 'text/plain', 'csv', '127', '0', '2025-11-19 19:58:03', NULL, '0', '0', NULL);
INSERT INTO `files` VALUES ('5', '5', '2', 'Bored_Valkyrie__1__1763560017_691dca51536f0.png', 'user_5\\Bored_Valkyrie__1__1763560017_691dca51536f0.png', NULL, 'Bored_Valkyrie (1).png', NULL, 'image/png', 'png', '25354', '0', '2025-11-19 20:46:57', NULL, '0', '1', '2025-11-20 12:07:19');
INSERT INTO `files` VALUES ('6', '3', '1', 'get_return_label_1763624799_691ec75f2d86a.pdf', 'user_3\\get_return_label_1763624799_691ec75f2d86a.pdf', NULL, 'get_return_label.pdf', NULL, 'application/pdf', 'pdf', '103766', '0', '2025-11-20 14:46:39', NULL, '0', '0', NULL);
INSERT INTO `files` VALUES ('11', '3', '5', 'users_export_2025-11-20_09-21-44__1__1763633814_691eea969f371.csv', 'user_3\\users_export_2025-11-20_09-21-44__1__1763633814_691eea969f371.csv', NULL, 'sasa.csv', NULL, 'application/csv', 'csv', '292', '1', '2025-11-20 17:16:54', '2025-11-20 21:36:28', '0', '0', NULL);
INSERT INTO `files` VALUES ('12', '5', '8', 'index__2__1763640688_691f057039fe0.php', 'user_5\\index__2__1763640688_691f057039fe0.php', NULL, 'index (2).php', NULL, 'text/html', 'php', '28838', '0', '2025-11-20 19:11:28', NULL, '0', '0', NULL);
INSERT INTO `files` VALUES ('13', '5', '8', 'index__2__1763640734_691f059e6ae59.php', 'user_5\\index__2__1763640734_691f059e6ae59.php', NULL, 'index (2).php', NULL, 'text/html', 'php', '28838', '0', '2025-11-20 19:12:14', NULL, '1', '0', NULL);
INSERT INTO `files` VALUES ('14', '3', '2', 'Bored_Valkyrie__1__1763645473_691f182192eca.png', 'user_3\\Bored_Valkyrie__1__1763645473_691f182192eca.png', NULL, 'Bored_Valkyrie (1).png', NULL, 'image/png', 'png', '25354', '1', '2025-11-20 20:31:13', '2025-11-20 21:36:31', '0', '0', NULL);
INSERT INTO `files` VALUES ('15', '3', '1', 'get_return_label_1763645484_691f182c37779.pdf', 'user_3\\get_return_label_1763645484_691f182c37779.pdf', NULL, 'get_return_label.pdf', NULL, 'application/pdf', 'pdf', '103766', '0', '2025-11-20 20:31:24', NULL, '1', '0', NULL);
INSERT INTO `files` VALUES ('16', '3', '1', 'TESTING_CC_1763648330_691f234a4994a.docx', 'user_3\\TESTING_CC_1763648330_691f234a4994a.docx', NULL, 'aaa.pdf', NULL, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', '1654762', '1', '2025-11-20 21:18:50', '2025-11-21 07:05:33', '0', '1', '2025-11-21 01:30:58');
INSERT INTO `files` VALUES ('17', '3', '1', 'get_return_label_1763648338_691f235266437.pdf', 'user_3\\get_return_label_1763648338_691f235266437.pdf', NULL, 'asa.pdf', NULL, 'application/pdf', 'pdf', '103766', '1', '2025-11-20 21:18:58', '2025-11-20 22:24:08', '0', '1', '2025-11-21 01:07:31');

-- Table: file_categories
DELETE FROM `file_categories`;
INSERT INTO `file_categories` VALUES ('1', 'Documents', 'documents', 'Document files including PDF, Word, Text files', 'pdf,doc,docx,txt,rtf,odt', '52428800', 'fa-file-text', '#3498db', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('2', 'Images', 'images', 'Image files including PNG, JPG, GIF, SVG', 'jpg,jpeg,png,gif,bmp,svg,webp,ico', '10485760', 'fa-image', '#e74c3c', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('3', 'Videos', 'videos', 'Video files including MP4, AVI, MOV, MKV', 'mp4,avi,mov,mkv,wmv,flv,webm,m4v', '524288000', 'fa-video', '#9b59b6', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('4', 'Audio', 'audio', 'Audio files including MP3, WAV, OGG', 'mp3,wav,ogg,m4a,flac,aac,wma', '52428800', 'fa-music', '#1abc9c', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('5', 'Spreadsheets', 'spreadsheets', 'Spreadsheet files including Excel, CSV', 'xlsx,xls,csv,ods', '20971520', 'fa-table', '#27ae60', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('6', 'Presentations', 'presentations', 'Presentation files including PowerPoint', 'ppt,pptx,odp,key', '52428800', 'fa-presentation', '#f39c12', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('7', 'Archives', 'archives', 'Compressed archive files', 'zip,rar,7z,tar,gz,bz2', '104857600', 'fa-archive', '#95a5a6', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('8', 'Code', 'code', 'Source code and programming files', 'php,js,html,css,json,xml,sql,py,java,cpp,c,h,sh', '5242880', 'fa-code', '#34495e', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');
INSERT INTO `file_categories` VALUES ('9', 'Others', 'others', 'Other file types not categorized', '*', '104857600', 'fa-file', '#7f8c8d', '1', '2025-11-19 18:42:01', '2025-11-19 18:42:01');

-- Table: file_storage_paths
DELETE FROM `file_storage_paths`;
INSERT INTO `file_storage_paths` VALUES ('1', '1', '5', 'uploads\\user_5', 'user_5\\activity_logs_2025-11-19_12-56-26_1763557042_691dbeb2d8a01.csv', NULL, 'activity_logs_2025-11-19_12-56-26.csv', 'activity_logs_2025-11-19_12-56-26_1763557042_691dbeb2d8a01.csv', '127', 'text/plain', 'csv', '0', NULL, '0', NULL, '2025-11-19 19:57:22', '2025-11-19 19:57:22');
INSERT INTO `file_storage_paths` VALUES ('2', '2', '5', 'uploads\\user_5', 'user_5\\2025-2026_ganjil_tugas_activity_diagram_1763557053_691dbebd6a842.docx', NULL, '2025-2026 ganjil tugas activity diagram.docx', '2025-2026_ganjil_tugas_activity_diagram_1763557053_691dbebd6a842.docx', '274238', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', '1', '2025-11-19 20:18:01', '0', NULL, '2025-11-19 19:57:33', '2025-11-19 20:18:27');
INSERT INTO `file_storage_paths` VALUES ('4', '4', '5', 'uploads\\user_5', 'user_5\\activity_logs_2025-11-19_12-56-26_1763557083_691dbedba9a68.csv', NULL, 'activity_logs_2025-11-19_12-56-26.csv', 'activity_logs_2025-11-19_12-56-26_1763557083_691dbedba9a68.csv', '127', 'text/plain', 'csv', '0', NULL, '0', NULL, '2025-11-19 19:58:03', '2025-11-19 19:58:03');
INSERT INTO `file_storage_paths` VALUES ('5', '5', '5', 'uploads\\user_5', 'user_5\\Bored_Valkyrie__1__1763560017_691dca51536f0.png', NULL, 'Bored_Valkyrie (1).png', 'Bored_Valkyrie__1__1763560017_691dca51536f0.png', '25354', 'image/png', 'png', '0', NULL, '1', '2025-11-20 12:07:19', '2025-11-19 20:46:57', '2025-11-20 18:07:19');
INSERT INTO `file_storage_paths` VALUES ('6', '6', '3', 'uploads\\user_3', 'user_3\\get_return_label_1763624799_691ec75f2d86a.pdf', NULL, 'get_return_label.pdf', 'get_return_label_1763624799_691ec75f2d86a.pdf', '103766', 'application/pdf', 'pdf', '0', NULL, '0', NULL, '2025-11-20 14:46:39', '2025-11-21 06:12:09');
INSERT INTO `file_storage_paths` VALUES ('11', '11', '3', 'uploads\\user_3', 'user_3\\users_export_2025-11-20_09-21-44__1__1763633814_691eea969f371.csv', NULL, 'sasa.csv', 'users_export_2025-11-20_09-21-44__1__1763633814_691eea969f371.csv', '292', 'application/csv', 'csv', '1', '2025-11-20 21:36:28', '0', NULL, '2025-11-20 17:16:54', '2025-11-20 21:55:14');
INSERT INTO `file_storage_paths` VALUES ('12', '12', '5', 'uploads\\user_5', 'user_5\\index__2__1763640688_691f057039fe0.php', NULL, 'index (2).php', 'index__2__1763640688_691f057039fe0.php', '28838', 'text/html', 'php', '0', NULL, '0', NULL, '2025-11-20 19:11:28', '2025-11-20 19:11:28');
INSERT INTO `file_storage_paths` VALUES ('13', '13', '5', 'uploads\\user_5', 'user_5\\index__2__1763640734_691f059e6ae59.php', NULL, 'index (2).php', 'index__2__1763640734_691f059e6ae59.php', '28838', 'text/html', 'php', '0', NULL, '0', NULL, '2025-11-20 19:12:14', '2025-11-20 19:12:14');
INSERT INTO `file_storage_paths` VALUES ('14', '14', '3', 'uploads\\user_3', 'user_3\\Bored_Valkyrie__1__1763645473_691f182192eca.png', NULL, 'Bored_Valkyrie (1).png', 'Bored_Valkyrie__1__1763645473_691f182192eca.png', '25354', 'image/png', 'png', '1', '2025-11-20 21:36:31', '0', NULL, '2025-11-20 20:31:13', '2025-11-20 21:36:31');
INSERT INTO `file_storage_paths` VALUES ('15', '15', '3', 'uploads\\user_3', 'user_3\\get_return_label_1763645484_691f182c37779.pdf', NULL, 'get_return_label.pdf', 'get_return_label_1763645484_691f182c37779.pdf', '103766', 'application/pdf', 'pdf', '0', NULL, '0', NULL, '2025-11-20 20:31:24', '2025-11-20 20:31:24');
INSERT INTO `file_storage_paths` VALUES ('16', '16', '3', 'uploads\\user_3', 'user_3\\TESTING_CC_1763648330_691f234a4994a.docx', NULL, 'aaa.pdf', 'TESTING_CC_1763648330_691f234a4994a.docx', '1654762', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', '1', '2025-11-21 07:05:33', '1', '2025-11-21 01:30:58', '2025-11-20 21:18:50', '2025-11-21 07:30:58');
INSERT INTO `file_storage_paths` VALUES ('17', '17', '3', 'uploads\\user_3', 'user_3\\get_return_label_1763648338_691f235266437.pdf', NULL, 'asa.pdf', 'get_return_label_1763648338_691f235266437.pdf', '103766', 'application/pdf', 'pdf', '1', '2025-11-20 22:24:08', '1', '2025-11-21 01:07:31', '2025-11-20 21:18:58', '2025-11-21 07:07:31');

-- Table: storage_requests
DELETE FROM `storage_requests`;
INSERT INTO `storage_requests` VALUES ('1', '3', '12884901888', '1073741824', '12', 'approved', '1', NULL, '2025-11-20 14:44:47', '2025-11-20 22:35:48');
INSERT INTO `storage_requests` VALUES ('2', '5', '42949672960', '10737418240', 'aku mau', 'approved', '1', NULL, '2025-11-20 22:36:14', '2025-11-20 22:36:35');

-- Table: activity_logs
DELETE FROM `activity_logs`;
INSERT INTO `activity_logs` VALUES ('1', NULL, 'EXPORT_USERS', 'Exported 2 user records to CSV', '2025-11-19 18:56:26', '::1');
INSERT INTO `activity_logs` VALUES ('2', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-19 18:56:26', '::1');
INSERT INTO `activity_logs` VALUES ('3', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-19_13-26-09.zip ( bytes, 0 files included)', '2025-11-19 19:26:09', '::1');
INSERT INTO `activity_logs` VALUES ('4', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-19_13-28-35.zip (0 bytes, 0 files included)', '2025-11-19 19:28:35', '::1');
INSERT INTO `activity_logs` VALUES ('5', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-19_13-28-39.zip (0 bytes, 0 files included)', '2025-11-19 19:28:39', '::1');
INSERT INTO `activity_logs` VALUES ('6', NULL, 'MANUAL_ENTRY', '2233', '2025-11-20 15:18:31', '::1');
INSERT INTO `activity_logs` VALUES ('7', NULL, 'MANUAL_ENTRY', '323232333', '2025-11-20 15:18:34', '::1');
INSERT INTO `activity_logs` VALUES ('8', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-20 15:20:39', '::1');
INSERT INTO `activity_logs` VALUES ('9', NULL, 'EXPORT_USERS', 'Exported 3 user records to CSV', '2025-11-20 15:21:04', '::1');
INSERT INTO `activity_logs` VALUES ('10', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-20 15:21:42', '::1');
INSERT INTO `activity_logs` VALUES ('11', NULL, 'EXPORT_USERS', 'Exported 3 user records to CSV', '2025-11-20 15:21:44', '::1');
INSERT INTO `activity_logs` VALUES ('12', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-20_09-28-30.zip (0 bytes, 0 files included)', '2025-11-20 15:28:31', '::1');
INSERT INTO `activity_logs` VALUES ('13', NULL, 'DELETE_INTERNAL_FILE', 'Deleted file: 1763627564_users_export_2025-11-20_09-21-44.csv', '2025-11-20 15:32:47', '::1');
INSERT INTO `activity_logs` VALUES ('14', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-20_13-52-49.zip (14912129 bytes, 26 files included)', '2025-11-20 19:52:50', '::1');
INSERT INTO `activity_logs` VALUES ('15', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-20_13-53-17.zip (14912159 bytes, 26 files included)', '2025-11-20 19:53:17', '::1');
INSERT INTO `activity_logs` VALUES ('16', NULL, 'DELETE_INTERNAL_FILE', 'Deleted file: 1763643402_index__2_.php', '2025-11-20 19:56:44', '::1');
INSERT INTO `activity_logs` VALUES ('17', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-20 20:24:51', '::1');
INSERT INTO `activity_logs` VALUES ('18', NULL, 'EXPORT_USERS', 'Exported 3 user records to CSV', '2025-11-20 20:24:55', '::1');
INSERT INTO `activity_logs` VALUES ('19', NULL, 'DELETE_INTERNAL_FILE', 'Deleted file: 1763653173_asa.pdf', '2025-11-20 22:39:37', '::1');
INSERT INTO `activity_logs` VALUES ('20', NULL, 'DELETE_INTERNAL_FILE', 'Deleted file: 1763653593_asa.pdf', '2025-11-20 22:46:35', '::1');
INSERT INTO `activity_logs` VALUES ('21', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-20 22:55:58', '::1');
INSERT INTO `activity_logs` VALUES ('22', NULL, 'BACKUP_SERVER', 'Created server backup: server_backup_2025-11-20_16-59-05.zip (16708691 bytes, 31 files included)', '2025-11-20 22:59:06', '::1');
INSERT INTO `activity_logs` VALUES ('23', NULL, 'BACKUP_USERS_SQL', 'Created users table SQL backup: users_table_backup_2025-11-20_16-59-18.sql (1805 bytes, 4 users)', '2025-11-20 22:59:18', '::1');
INSERT INTO `activity_logs` VALUES ('24', NULL, 'BACKUP_USERS_SQL', 'Created users table SQL backup: users_table_backup_2025-11-21_01-44-12.sql (1805 bytes, 4 users)', '2025-11-21 07:44:12', '::1');
INSERT INTO `activity_logs` VALUES ('25', NULL, 'EXPORT_LOGS', 'Exported activity logs to CSV', '2025-11-21 07:45:58', '::1');
INSERT INTO `activity_logs` VALUES ('26', NULL, 'BACKUP_USERS_SQL', 'Created users table SQL backup: users_table_backup_2025-11-21_01-50-17.sql (1805 bytes, 4 users)', '2025-11-21 07:50:17', '::1');

